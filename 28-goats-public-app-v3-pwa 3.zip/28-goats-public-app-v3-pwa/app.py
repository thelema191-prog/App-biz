from flask import Flask, render_template, request, jsonify, redirect, send_from_directory
from datetime import date, time, datetime
from models import init_db, SessionLocal, Appointment, InboundSMS
import os, stripe, json
from emailer import send_email, notify_owner, wrap_email
from sms import send_sms, sms_enabled
from werkzeug.utils import secure_filename

app = Flask(__name__)
init_db()

APP_NAME = "28 Goats Lawn Care"
APP_BASE_URL = os.environ.get("APP_BASE_URL", "http://127.0.0.1:5000")
ADMIN_TOKEN = os.environ.get("ADMIN_TOKEN")
PUBLISHABLE_KEY = os.environ.get("STRIPE_PUBLISHABLE_KEY", "")
stripe.api_key = os.environ.get("STRIPE_SECRET_KEY", "")
STRIPE_WEBHOOK_SECRET = os.environ.get("STRIPE_WEBHOOK_SECRET")

UPLOAD_FOLDER = os.path.join("static","uploads")
ALLOWED_EXT = {"png","jpg","jpeg","webp"}

SERVICES = {
    "mow_month": ("Mow & weedeat — monthly (weekly cuts)", 350.00, True),
    "wash_season": ("Pressure wash house — season package", 700.00, True),
    "wash_single": ("Pressure wash house — single wash", 400.00, True),
    "upkeep_quote": ("Landscape upkeep — free quote", 0.0, False),
    "gutter_quote": ("Gutter cleaning — free quote", 0.0, False),
}

def compute_price(service_code: str, veteran: bool) -> float:
    label, base, is_paid = SERVICES[service_code]
    if not is_paid: return 0.0
    if service_code == "mow_month" and veteran: return 200.0
    return round(base * (0.9 if veteran else 1.0), 2)

@app.get("/manifest.json")
def manifest():
    return send_from_directory("static", "manifest.json", mimetype="application/manifest+json")

@app.get("/service-worker.js")
def sw():
    return send_from_directory("static", "service-worker.js", mimetype="application/javascript")

@app.get("/")
def index():
    return render_template("index.html", services=SERVICES, publishable_key=PUBLISHABLE_KEY, app_name=APP_NAME, sms_on=sms_enabled())

@app.get("/gallery")
def gallery():
    files = sorted([f for f in os.listdir(UPLOAD_FOLDER) if f.split(".")[-1].lower() in {"png","jpg","jpeg","webp"}])
    return render_template("gallery.html", files=files)

@app.get("/faq")
def faq():
    return render_template("faq.html")

@app.get("/admin")
def admin():
    token = request.args.get("token")
    if not ADMIN_TOKEN or token != ADMIN_TOKEN: return "Unauthorized", 401
    with SessionLocal() as s:
        appts = s.query(Appointment).order_by(Appointment.created_at.desc()).all()
        sms_list = s.query(InboundSMS).order_by(InboundSMS.created_at.desc()).limit(50).all()
        return render_template("admin.html", appts=appts, sms_list=sms_list)

@app.get("/admin/upload")
def upload_page():
    token = request.args.get("token")
    if not ADMIN_TOKEN or token != ADMIN_TOKEN: return "Unauthorized", 401
    return render_template("upload.html")

@app.post("/admin/upload")
def upload_files():
    token = request.args.get("token")
    if not ADMIN_TOKEN or token != ADMIN_TOKEN: return "Unauthorized", 401
    files = request.files.getlist("photos")
    for f in files:
        if not f.filename: continue
        ext = f.filename.rsplit(".",1)[-1].lower()
        if ext not in {"png","jpg","jpeg","webp"}: continue
        from werkzeug.utils import secure_filename
        name = secure_filename(f.filename)
        path = os.path.join(UPLOAD_FOLDER, name)
        f.save(path)
    return redirect("/gallery")

@app.post("/api/book")
def book():
    data = request.json or {}
    name = data.get("name","").strip()
    phone = data.get("phone","").strip()
    email = data.get("email","").strip()
    address = data.get("address","").strip()
    service_code = data.get("service_code")
    appt_date = date.fromisoformat(data.get("date"))
    appt_time = time.fromisoformat(data.get("time"))
    veteran = bool(data.get("veteran_police"))
    sms_opt_in = bool(data.get("sms_opt_in"))
    notes = (data.get("notes") or "").strip()
    tip = float(data.get("tip") or 0.0)

    if service_code not in SERVICES: return jsonify({"error":"Unknown service"}), 400

    label, base, is_paid = SERVICES[service_code]
    price = compute_price(service_code, veteran)
    with SessionLocal() as s:
        appt = Appointment(
            name=name, phone=phone, email=email, address=address,
            service_code=service_code, service_label=label,
            appt_date=appt_date, appt_time=appt_time,
            veteran_police=veteran, sms_opt_in=sms_opt_in,
            notes=notes, price=price, tip=tip, status="Scheduled"
        )
        s.add(appt); s.commit(); s.refresh(appt)

        notify_owner("New Booking - 28 Goats", f"<div>#{appt.id} — {name} — {label} on {appt.appt_date} {appt.appt_time}</div>")
        send_email(email, "Your Booking Confirmation - 28 Goats", wrap_email("Booking Confirmed", f"Service: {label}<br>Date/Time: {appt.appt_date} {appt.appt_time}<br>Price: ${price:.2f}<br>Tip: ${tip:.2f}"))
        if sms_opt_in and phone:
            from sms import send_sms
            send_sms(phone, f"🐐 28 Goats: Booked {label} on {appt.appt_date} at {appt.appt_time}. Reply STOP to opt out.")

        if price == 0:
            return jsonify({"quote": True, "appointment_id": appt.id})

        line_items = [{
            "quantity": 1,
            "price_data": {
                "currency": "usd",
                "unit_amount": int(price * 100),
                "product_data": {"name": label + (" (Veteran/Police)" if veteran else "")}
            }
        }]
        if tip and tip > 0:
            line_items.append({
                "quantity": 1,
                "price_data": {
                    "currency": "usd",
                    "unit_amount": int(tip * 100),
                    "product_data": {"name": "Tip for crew"}
                }
            })
        session = stripe.checkout.Session.create(
            mode="payment",
            success_url=f"{APP_BASE_URL}/success?aid=",
            cancel_url=f"{APP_BASE_URL}/cancel",
            line_items=line_items,
            metadata={"service_code": service_code},
        )
        return jsonify({"checkout_session_id": session.id, "public_key": PUBLISHABLE_KEY})

@app.post("/webhook/stripe")
def stripe_webhook():
    payload = request.data
    return "ok", 200

@app.post("/webhook/twilio")
def twilio_webhook():
    from_number = request.form.get("From", "")
    body = request.form.get("Body", "")
    with SessionLocal() as s:
        msg = InboundSMS(from_number=from_number, body=body)
        s.add(msg); s.commit()
    notify_owner("SMS Reply - 28 Goats", f"<b>{from_number}</b>: {body}")
    return ('<?xml version="1.0" encoding="UTF-8"?><Response><Message>Thanks! We got your message.</Message></Response>', 200, {"Content-Type":"application/xml"})

@app.get("/tasks/send_reminders")
def send_reminders():
    return jsonify({"ok": True})

@app.get("/success")
def success():
    return render_template("success.html")

@app.get("/cancel")
def cancel():
    return render_template("cancel.html")

if __name__ == "__main__":
    app.run(host="0.0.0.0", port=5000, debug=True)
