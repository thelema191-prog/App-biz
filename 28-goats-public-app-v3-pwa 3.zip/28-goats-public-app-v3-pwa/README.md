# 28 Goats — v3 + PWA (Installable App)
[Full README content omitted for brevity in this cell]