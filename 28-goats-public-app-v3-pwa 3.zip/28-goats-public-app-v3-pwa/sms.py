import os
from twilio.rest import Client

def sms_enabled():
    return bool(os.environ.get("TWILIO_ACCOUNT_SID") and os.environ.get("TWILIO_AUTH_TOKEN") and os.environ.get("TWILIO_FROM"))

def send_sms(to: str, body: str):
    if not sms_enabled():
        return False
    try:
        client = Client(os.environ["TWILIO_ACCOUNT_SID"], os.environ["TWILIO_AUTH_TOKEN"])
        client.messages.create(body=body, from_=os.environ["TWILIO_FROM"], to=to)
        return True
    except Exception:
        return False
